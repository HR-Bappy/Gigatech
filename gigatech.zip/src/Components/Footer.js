import React from "react";
import "../assets/css/Footer.css";
export default function Footer() {
  return (
    <div className="footer">
      <div className="info row">
        <p>Habibur Rahman &nbsp; &nbsp; &nbsp; mdhabiburrb@gmail.com</p>
      </div>
    </div>
  );
}
